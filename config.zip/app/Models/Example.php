<?php

namespace App\Models;

use Core\Model;

class Example extends Model {
    protected string $table = 'example_table';      // Define the table name
    protected string $primaryKey = 'example_id';    // Define the primary key (if different from default)
}
