<?php

return [
    'db_host'    => 'localhost',    // Database server host
    'db_port'    => '1433',         // SQL Server port (default 1433)
    'db_name'    => 'your_database', // Database name
    'db_user'    => 'your_user',     // Username
    'db_pass'    => 'your_password', // Password
    'db_charset' => 'utf8',          // Character set
];