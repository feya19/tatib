<?php

namespace Core;

class Controller {
    public static function view(string $view, array $data = []): void {
        extract($data);
        include __DIR__ . '/../views/' . $view . '.php';
    }

    public static function render(string $contentView, array $data = []): void {
        // Load header
        self::view('header', $data);

        // Load main content
        self::view($contentView, $data);

        // Load footer
        self::view('footer', $data);
    }
}
