<?php

namespace Core;

use PDO;
use PDOException;

class Database {
    private string $host;
    private string $port;
    private string $database;
    private string $username;
    private string $password;
    private string $charset;
    private PDO $connection;

    public function __construct() {
        // Load database configuration from `config.php`
        $config = include __DIR__ . '/../config.php';

        $this->host = $config['db_host'];
        $this->port = $config['db_port'];
        $this->database = $config['db_name'];
        $this->username = $config['db_user'];
        $this->password = $config['db_pass'];
        $this->charset = $config['db_charset'];

        $this->connect();
    }

    private function connect(): void {
        try {
            $dsn = "sqlsrv:Server={$this->host},{$this->port};Database={$this->database}";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            $this->connection = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    public function getConnection(): PDO {
        return $this->connection;
    }
}
