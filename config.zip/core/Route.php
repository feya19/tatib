<?php

namespace Core;

class Route {
    private static array $routes = [];

    /**
     * Add a GET route.
     */
    public static function get(string $uri, string $action): void {
        self::$routes['GET'][$uri] = $action;
    }

    /**
     * Add a POST route.
     */
    public static function post(string $uri, string $action): void {
        self::$routes['POST'][$uri] = $action;
    }

    /**
     * Dispatch the current request to the appropriate controller and method.
     */
    public static function dispatch(): void {
        $uri = self::getUri();
        $method = $_SERVER['REQUEST_METHOD'];
    
        echo "Debug: URI = '$uri', Method = '$method'<br>"; // Add this line to debug
    
        if (isset(self::$routes[$method][$uri])) {
            [$controller, $action] = explode('@', self::$routes[$method][$uri]);
    
            $controllerClass = 'App\\Controllers\\' . $controller;
    
            if (class_exists($controllerClass)) {
                $controllerInstance = new $controllerClass();
    
                if (method_exists($controllerInstance, $action)) {
                    call_user_func_array([$controllerInstance, $action], []);
                    return;
                }
            }
        }
    
        // Route not found
        http_response_code(404);
        echo "404 Not Found";
    }
    

    /**
     * Get the current URI (strips query parameters).
     */
    private static function getUri(): string {
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $baseDir = '/tatib/'; // Add your subdirectory here
        $uri = str_replace($baseDir, '', $uri); // Remove the base directory
        return trim($uri, '/');
    }
}
