<?php

require_once __DIR__ . '/../core/App.php';
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../core/Route.php';
require_once __DIR__ . '/../config/Config.php';

use Core\Route;

// Define routes
Route::get('/', 'HomeController@index'); // Default route
Route::get('pdf', 'HomeController@pdf'); // PDF generation route

// Dispatch the request
Route::dispatch();
